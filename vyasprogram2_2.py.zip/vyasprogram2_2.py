# Jay Vyas
# Spc ID #: 2546420
# Course number: COP 1000
# Collaborator: none

## Pseudocode:
#1. Prompt the user to input the number of hours.
#2. Convert the input into an integer.
#3. Use integer divison to calculate the number of days.
#4. Use the modulus operator to calculate the remaning hours.
#5. Output the result in the format

def main():
    #Input the number of hours
    hours = 50

    #Perform the conversion using integer division and modulus operator
    days = hours // 24
    remaning_hours = hours % 24

    #Output the result in the specificifed format
    print(f"{hours} hours is equivalent to {days} days and {remaning_hours} hours")

main()
