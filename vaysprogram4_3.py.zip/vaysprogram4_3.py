# Name: Jay Vyas
# SPC ID: 2546420
# Course: COP 1000
# Collaborator: none

# Pseudocode
# Use three nested loops to generate the pattern
# Outer loop runs 4 times for four hollow squares
# First inner loop prints the top row
# Second inner loop prints the middle rows with spaces in between
# Third inner loop prints the bottom row
# Ensure correct formatting with spacing and alignment

def print_hollow_square():
    # The width and height of the square
    size = 10
    # Print the pattern 4 times
    for _ in range(4):
        for i in range(size):
            if i == 0 or i == size - 1:
                print("".join(str(j) for j in range(size)))
            else:
                print("0" + " " * (size - 2) + "9")
        # Blank line to separate squares
        print()

# Call function to print the pattern
print_hollow_square()
