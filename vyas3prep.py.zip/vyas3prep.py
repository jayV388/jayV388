#Jay Vyas
#Spc ID:2546420
#Course: COP 1000
#Collaborator: None

# Pseudocode:
# 1. Define coffee prices based on weight brackets.
# 2. Prompt the user to enter the number of pounds desired.
# 3. Calculate the cost of coffee based on the number of pounds ordered.
# 4. Compute the 7% sales tax on the cost of coffee.
# 5. Determine shipping charges: $1 per pound unless the total cost of coffee exceeds $150 (before tax).
# 6. Calculate the total amount due.
# 7. Display all values (cost of coffee, tax, shipping charges, total) formatted as currency.

# Coffee price brackets
def get_price_per_pound(weight):
    if weight >= 50:
        return 6.50
    elif weight >= 30:
        return 8.00
    elif weight >= 15:
        return 9.50
    else:
        return 11.00

# Constants
sales_tax_rate = 0.07
shipping_cost_per_pound = 2.00
free_shipping_threshold = 200.00

# Prompt user input
try:
    pounds_ordered = int(input("How many pounds are you ordering? "))
    if pounds_ordered <= 0:
        raise ValueError("Weight must be a positive integer.")
except ValueError as e:
    print(f"Invalid input: {e}")
    exit()

# Calculate the cost of coffee
price_per_pound = get_price_per_pound(pounds_ordered)
cost_of_coffee = price_per_pound * pounds_ordered

# Calculate sales tax
sales_tax = cost_of_coffee * sales_tax_rate

# Determine shipping charges
if cost_of_coffee > free_shipping_threshold:
    shipping_fee = 0.00
else:
    shipping_fee = pounds_ordered * shipping_cost_per_pound

# Calculate total amount due
total_payable = cost_of_coffee + sales_tax + shipping_fee

# Display results
print(f"Cost of coffee: ${cost_of_coffee:.2f}")
print(f"7% sales tax: ${sales_tax:.2f}")
print(f"Shipping fee: ${shipping_fee:.2f}")
print(f"Total payable: ${total_payable:.2f}")
