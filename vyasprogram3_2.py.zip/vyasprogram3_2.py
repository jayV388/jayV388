# Jay Vyas
# SPC ID# 2546420
# Course: COP 1000
# Collaborator: None

# Pseudocode:
# 1. Prompt the user to enter three fasting blood sugar readings as integers.
# 2. Identify the highest of the three readings.
# 3. Use Boolean variables to indicate which readings should be included in the average.
# 4. Calculate the average of the two lowest readings, excluding the highest reading.
# 5. Print the calculated average in one statement using the walrus operator.

# Start of the program
def main():
    try:
        # Prompt the user for three readings
        first_reading = int(input("Enter first fasting blood sugar reading in mg/dL: "))
        second_reading = int(input("Enter second fasting blood sugar reading in mg/dL: "))
        third_reading = int(input("Enter third fasting blood sugar reading in mg/dL: "))
    except ValueError:
        print("Invalid input. Please enter integers only.")
        exit()

    # Identify the highest reading
    highest_reading = max(first_reading, second_reading, third_reading)

    # Use Boolean variables to include the two lowest readings
    use_first = first_reading != highest_reading
    use_second = second_reading != highest_reading
    use_third = third_reading != highest_reading

    # Calculate the average of the two lowest readings
    average = ((first_reading if use_first else 0) + (second_reading if use_second else 0) + (third_reading if use_third else 0)) / 2

    # Print the average
    print(f"The average blood sugar for the patient is {average:.1f} mg/dL")

# Call the main function
main()
