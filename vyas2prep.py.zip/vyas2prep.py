# Jay Vyas
# Spc ID #: 2546420
# Course number: COP 1000
# Collaborator: none

## Pseudocode:
#1. Prompt the user to enter the three test scores as integers.
#2. Set the results in variable with their names that are descriptive.
#3. Calculate the average of three scores.
#4. Format the average as a percentage with two decimals places.
#5. Display the result to the user with the '%' symbol.

def main():
    
    # Prompt the user to enter test scores with their names.
    test_score1 = 95
    test_score2 = 80
    test_score3 = 85

    #Calculate the average score
    average_score = (test_score1 + test_score2 + test_score3)/ 3

    #Format the result to two decimal places with the '%' symbol
    formatted_average = f'{average_score:.2f}%'

    # Output the result
    print(f'The average of these scores is {formatted_average}.')

main ()
