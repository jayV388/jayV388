# Jay Vyas
#SPC ID# 2546420
#Course: COP 1000
# Collaborator: none

# Pseudocode:
# 1. Prompt the user to input the number of guitar picks they wish to buy as an integer.
# 2. Validate the input to ensure it is a positive integer.
#    -If the input is invalid (negative or non-integer), display an error message and terminate the program.
# 3. Determine the price per pick based on the quantity using the following rules:
#    - Less than 12 picks: 25 cents each
#    - 12 or more picks: 23 cents each
#    - 24 or more picks: 21 cents each
#    - 36 or more picks: 19 cents each
# 4. Calculate the total cost by multiplying the number of picks by the price per pick.
# 5. Format the total cost as currency with no space between the $ sign and the first digit, including commas if necessary.
# 6. Display the total cost to the user in the specified format.

def main():
    # Prompt the user for the number of guitar picks
    try:
        guitar_picks = int(input("How many guitar picks do you wish to buy? "))
        if guitar_picks <= 0:
            raise ValueError("The number of picks must be a positive integer.")
    except ValueError as e:
        print(f"Invalid input: {e}")
        exit()

    # Determine price per pick
    if guitar_picks >= 36:
        price_per_picks = 0.19
    elif guitar_picks >= 24:
        price_per_picks = 0.21
    elif guitar_picks >= 12:
        price_per_picks = 0.23
    else:
        price_per_picks = 0.25

    # Calculate total cost
    total_cost = guitar_picks * price_per_picks

    # Display total cost in currency format
    print(f"Total cost of guitar picks is: ${total_cost:,.2f}")

# Call the main function
main()

            
