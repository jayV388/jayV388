# Name: Jay Vyas
# SPC ID: 2546420
# Course: COP 1000
# Collaborator: none

# Pseudocode
# Prompt user to enter FSA contribution (max 3200)
# Validate the input to ensure it is a positive whole number within the allowed limit
# Initialize variables for expenditure count and total
# Use a while loop to continuously prompt user for FSA expenditures
# Stop loop when user enters 0
# Display total count of expenditures and total spent
# Compare total spent with FSA contribution and provide feedback

# Function to get validated whole number input
def get_whole_number(prompt, max_value=None):
    while True:
        value = input(prompt).strip()
        if value.isdigit():
            value = int(value)
            if max_value is None or value <= max_value:
                return value
        print(f"Error: Please enter a whole number up to {max_value if max_value is not None else 'a valid positive number'}.")

# Get user's FSA contribution
fsa_contribution = get_whole_number("Enter your FSA contribution for the year as a whole number (max allowed is 3200): ", 3200)

# Initialize variables
expenditure_count = 0
expenditure_total = 0

# Get user expenditures
while True:
    expenditure = get_whole_number("Enter the FSA expenditure as a whole number (enter 0 to finish): ")
    if expenditure == 0:
        break
    expenditure_count += 1
    expenditure_total += expenditure

# Print summary
print(f"\nYou have a count of {expenditure_count} FSA expenditures for the year.")
print(f"You have accumulated a total of ${expenditure_total} for the year.")

difference = fsa_contribution - expenditure_total
if difference == 0:
    print("Your expenditure total is the same as your FSA contribution.")
elif difference > 0:
    print(f"Your expenditure total is ${difference} under your FSA contribution for the year.")
else:
    print(f"Your expenditure total is ${abs(difference)} over your FSA contribution for the year.")
