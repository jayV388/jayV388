# Jay Vyas
# Scp ID#: 2546420
# Course number: COP 1000
#Collaborator: None

#Pseudocode:
#1. Prompt the user to input the cost of their mals as a decimal value.
#2. Prompt the user to input the tip percentage as a whole number.
#3. Deifne a constant for the tax rate 7%
#4. Calculate the tip amount by multiplying the meal cost by the tip percentage.
#5. Calculate the tax amount by multiplying the meal cost by the tax rate.
#6. Compute the grand total by summing the meal cost, tip and tax.
#7. Display the calculated tip amount, tax amount, and grand total in clear format.

def main():

    #Define the tax rate as a costant
    tax_rate = 7

    #Get the cost of the mail from the user
    meal_cost = 20

    # Get the tip percentage from the user
    tip_percent = 18

    # Calculate the tip in dollars
    tip_amount = (tip_percent / 100) * meal_cost

    # Calculate the tax in dollars
    tax_amount = (tax_rate /100) * meal_cost

    # Calculate the grand total
    grand_total = meal_cost + tip_amount + tax_amount

    #Display the results
    print(f'A ${meal_cost:.2f} meal with a {tip_percent}% tip of ${tip_amount:.2f} ' f'and 7% tax has a grand total cost of ${grand_total:.2f}.')

main ()
