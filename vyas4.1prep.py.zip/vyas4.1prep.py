# Name: Jay Vyas
# SPC ID: 2546420
# Course: COP 1000
# Collaborator: none

#1st Program
# Pseudocode:
# 1. Print the table header with column names: "INTS", "SQUARES", and "CUBES".
# 2. Format the header so numbers line up properly.
# 3. Use a loop to go through numbers from 5 to 50, increasing by 5 each time.
# 4. Calculate the square and cube of each number.
# 5. Print the number, its square, and its cube, making sure they are properly aligned.


# Print the table header with correct spacing and alignment.
print(f"{'INTS':^7} {'SQUARES':>8} {'CUBES':>12}")

# Start a loop from 5 to 50, increasing by 5.
for num in range(5, 51, 5):
    # Compute the square of the number.
    square = num ** 2
    # Compute the cube of the number.
    cube = num ** 3
    # Print the number, square, and cube, ensuring correct alignment and commas for readability.
    print(f"{num:^7} {square:>8,} {cube:>12,}")

# 2nd Program
# Pseudocode:
# 1. Prompt the user to enter an integer or 0 to quit.
# 2. Use a while loop that runs until the user enters 0.
# 3. Check if the number is even or odd.
# 4. Print the result.
# 5. If the number is 0, print "All done!" and stop the program.


# Start an infinite loop to get user input.
while True:
    # Prompt the user for input.
    num = int(input("Enter an integer or 0 to quit: "))

    # Check if the user entered 0.
    if num == 0:
        print("All done!")
        # Exit the loop.
        break

    # Determine if the number is even or odd.
    if num % 2 == 0:
        print(f"{num} is an even number")
    else:
        print(f"{num} is an odd number")
